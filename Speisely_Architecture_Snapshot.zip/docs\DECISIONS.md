# Speisely Confirmed Decisions

This document serves as the immutable record of approved architecture choices, product rules, and UX decisions. AI agents (like Antigravity) must **not** revisit or attempt to change these decisions without explicit user approval.

## 1. Architecture & Tech Stack
- **Framework:** React with TanStack Router (`@tanstack/react-router`) for full-stack routing and server functions (`createServerFn`).
- **Database / Backend:** Supabase (PostgreSQL, Auth, Edge Functions, Storage).
- **Styling:** Tailwind CSS with Radix UI components (shadcn/ui patterns).
- **Hosting:** Vercel (using Vercel Edge/Serverless functions for SSR).

## 2. Storefront Routing (Custom Domains & Subdomains)
- **Decision:** The storefront dynamically resolves partner profiles based on the `host` header.
- **Logic (`src/server.ts`):** 
  - If the host is a wildcard subdomain (e.g., `pizza.speisely.de`), it extracts `pizza` and matches it against the `slug` column in the database.
  - If the host is a custom domain (e.g., `pizzeria-napoli.com`), it matches against the `custom_domain` column.
- **Strict Rule:** Do not modify the `server.ts` request rewriting logic without high-level approval. It is critical for the White-label/SaaS offering.

## 3. Authentication & Account Structure
- **Decision:** A single user account can hold multiple roles simultaneously.
- **Rule:** We use a unified identity model. A user signs up once and can be a customer, a restaurant owner, and a caterer.
- **Middleware Execution:** `role-middleware.ts` handles "self-healing" by reading metadata upon login and inserting it into `user_roles`. It also injects a unified `partner` role if the user has any vendor role.
- **Strict Rule:** Do not attempt to split user accounts or force separate logins for different business verticals.

## 4. Operational Workspaces
- **Decision:** Dashboards are strictly separated by vertical.
- **Rule:** A Caterer manages catering inquiries in `/_authenticated/caterer`. A Restaurant manages instant orders in `/_authenticated/restaurant`.
- **Strict Rule:** Do not merge the UI of these dashboards. The operational contexts (Quoting vs Instant Fulfillment) are too different.

## 5. Checkout & Payments
- **Decision:** All payments run through Stripe Connect.
- **Rule:** Speisely acts as the platform. Customers checkout via Stripe Checkout Sessions, and funds are routed to the partner's connected Stripe account.
- **Security Rule:** `stripe_user_id` must be stored in secure, private tables (`restaurant_stripe_accounts`, etc.) to prevent public exposure via RLS.

## 6. Anti-Fraud & Date Logic
- **Decision:** Strict server-side date validation is required for all bookings.
- **Rule:** Customers can never book a date in the past. This is enforced via Zod schema validation in `createServerFn` AND database constraints.
- **Rule:** Availability logic must respect both recurring `availability` rules and specific `vendor_blackout_dates`.

## 7. Error Handling (404s)
- **Decision:** The storefront must gracefully handle missing slugs or unpublished restaurants.
- **Rule:** If `getRestaurant` (or equivalent) returns null for a slug, the loader must explicitly `throw notFound()`. Do not rely on empty component returns (`return null`), as TanStack Router requires the explicit throw to render the fallback 404 UI.
