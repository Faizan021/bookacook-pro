# Speisely Storefront Architecture & Routing Map

This document provides a strictly structured map of all public storefront routes, their underlying data sources, SEO strategies, and strict anti-fraud booking rules.

---

## 1. Directory & Discovery Routes

### Homepage
- **Route:** `/index.tsx`
- **Purpose:** Primary landing page for the Speisely platform. Funnels traffic into the three core verticals.
- **Audience:** All incoming public traffic.
- **Primary CTA:** Quick links / search inputs for Instant Food, Catering, and Event Planning.
- **Exact Data Sources:** Static content, potential dynamic features relying on `seo_content_pages`.
- **Related Dashboard Source:** Admin (`/admin/seo`) overrides.
- **Booking / Checkout Logic:** N/A (Redirects to verticals).
- **SEO / GEO Value:** High domain authority target. Branded search target.
- **Validation Rules:** None.
- **Status:** `Built` (static).
- **Risk Areas:** Low dynamic content means SEO value relies on deep-linking to verticals.

### Instant Order Directory
- **Route:** `/instant-order.tsx`
- **Purpose:** Browse restaurants offering instant takeaway/delivery.
- **Audience:** Customers wanting immediate food.
- **Primary CTA:** "View Menu" / "Order Now" leading to Restaurant Storefronts.
- **Exact Data Sources:** `restaurants` table (`is_active=true` / `is_published=true`), `product_categories`.
- **Related Dashboard Source:** Partner (`/_authenticated/restaurant`) controls visibility.
- **Booking / Checkout Logic:** Discovery only.
- **SEO / GEO Value:** Broad target for "Order food online [City]".
- **Validation Rules:** N/A.
- **Status:** `Built`.
- **Risk Areas:** Lack of bounding-box geospatial filtering.

### Catering Directories
- **Route:** `/catering.index.tsx` (and sub-routes like `/catering/events`, `/catering/institutional-catering`)
- **Purpose:** Browse and discover event and B2B caterers based on event type.
- **Audience:** Private event hosts, B2B office managers.
- **Primary CTA:** "Request Quote" / "View Caterer".
- **Exact Data Sources:** `caterers` table.
- **Related Dashboard Source:** Partner (`/_authenticated/caterer`) settings.
- **Booking / Checkout Logic:** Discovery only.
- **SEO / GEO Value:** Extremely high. Targets "Wedding catering [City]", "Office catering [City]".
- **Validation Rules:** N/A.
- **Status:** `Built`.
- **Risk Areas:** Sub-category logic relies heavily on proper tagging in the database.

---

## 2. Partner Storefront Routes (Booking Origins)

### Restaurant Storefront
- **Route:** `/restaurant/$slug.tsx`
- **Purpose:** Display a restaurant's menu, hours, and accept instant orders or table reservations.
- **Audience:** Diners and delivery customers.
- **Primary CTA:** "Add to Cart" or "Book Table".
- **Exact Data Sources:** 
  - Reads: `restaurants`, `restaurant_products`, `promo_codes`, `table_reservations` (for capacity).
  - Writes: `restaurant_orders`, `order_items`, `table_reservations`.
- **Related Dashboard Source:** Dashboard (`/_authenticated/restaurant`) for profile edits.
- **Booking / Checkout Logic:** Cart -> Validate -> `startStorefrontCheckout` (Stripe).
- **SEO / GEO Value:** Crucial local SEO ("Menu for [Restaurant Name] [City]").
- **Validation Rules (Anti-Fraud):**
  - **Table Booking:** Zod schema rejects past dates (`Date() >= today`). Requires available `seat_capacity` for the exact HH:MM slot.
  - **Orders:** Rejects checkout if `stripe_connect_status !== 'connected'`.
  - **Promo Validity:** Validates against `starts_at` and `ends_at`. Checks `min_order_value_cents`.
- **Status:** `Built`.
- **Risk Areas:** Cart state synchronization.

### Caterer Storefront
- **Route:** `/caterer/$slug.tsx` (and `/catering/$slug.tsx`)
- **Purpose:** Display catering packages and capture detailed event briefs.
- **Audience:** Event hosts.
- **Primary CTA:** "Request a Quote".
- **Exact Data Sources:** 
  - Reads: `caterers`, `caterer_menu_items`, `vendor_blackout_dates`, `availability`.
  - Writes: `catering_bookings`, `catering_briefs`.
- **Related Dashboard Source:** Dashboard (`/_authenticated/caterer`).
- **Booking / Checkout Logic:** Submits a brief -> Pending Status. Payment occurs later via dashboard-generated link.
- **SEO / GEO Value:** Crucial for niche catering SEO ("BBQ Caterer [City]").
- **Validation Rules (Anti-Fraud):**
  - **No Past Dates:** Blocks inquiry dates prior to today.
  - **Lead Time Rules:** Validates request date against the caterer's `lead_time_days` requirement.
  - **Availability Sync:** Cross-checks `availability` (e.g., closed Mondays) and blocks specific `vendor_blackout_dates`.
- **Status:** `Built`.
- **Risk Areas:** Lead-time timezone calculation edge cases.

### Event Planner Storefront
- **Route:** `/planner/$slug.tsx`
- **Purpose:** Showcase portfolio and services, capture event leads.
- **Audience:** Event hosts looking for organization/decoration.
- **Primary CTA:** "Contact Planner" / "Book Service".
- **Exact Data Sources:** 
  - Reads: `planners`, `planner_services`.
  - Writes: `event_bookings`.
- **Related Dashboard Source:** Dashboard (`/_authenticated/dashboard/planner`).
- **Booking / Checkout Logic:** Submits a lead -> In-app chat negotiation.
- **SEO / GEO Value:** High value for "Event decorator [City]". Image SEO (Portfolio) is critical.
- **Validation Rules (Anti-Fraud):**
  - **No Past Dates:** Form rejects past dates.
- **Status:** `Partial` (Portfolio gallery missing robust DB links).
- **Risk Areas:** Payment pipeline relies on manual invoicing outside the main checkout flow.

---

## 3. Storefront Routing vs Unified Partner Architecture

Speisely operates a **Unified Partner Identity** model internally, but presents **Isolated Operational Workspaces** to the user and the public.

**How Routing Connects to Unified Identity:**
1. **Public Face (Storefront):** The routing (`src/server.ts`) isolates the public experience. If a user visits `pizza.speisely.de`, the Edge function explicitly queries the `restaurants` table. It does *not* query caterers or planners. The public sees three distinct businesses.
2. **Dashboard Face (Workspaces):** A Partner logs in with a single email (unified identity). The `role-middleware.ts` grants them the `partner` role.
3. **Operational Isolation:** Once logged in, the UI enforces strict boundaries:
   - To manage pizza orders, they go to `/_authenticated/restaurant`.
   - To manage catering quotes, they go to `/_authenticated/caterer`.
   - The UI never mixes these data sources. The backend enforces RLS so the partner can securely write to `restaurants` or `caterers` seamlessly, but the public URL (`/restaurant/pizza`) always maps exactly to the isolated `restaurants` operational table.

**Benefit:** 
Partners manage all their ventures from one login, avoiding account juggling. Meanwhile, customers and search engines see dedicated, hyper-focused landing pages that rank well and avoid confusing user experiences (e.g., mixing a live pizza order with a 3-week catering quote request).
