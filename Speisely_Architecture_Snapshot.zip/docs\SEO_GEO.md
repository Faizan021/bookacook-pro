# Speisely SEO & GEO Strategy

This document maps the technical SEO structure and Geographic discovery (GEO) strategy for organic growth, based on the current codebase.

## 1. GEO Definition: Geographic Discovery & Local SEO

**Concept:** 
GEO in Speisely refers strictly to **location-based programmatic landing pages and local discovery**. It dictates how users find partners when searching for queries like "Catering in Berlin" or "Pizza delivery in Munich".

**Database Structure (`german_locations`):**
- Contains cities, zip codes, and geographic coordinates.
- **Implemented:** `Built`. Seeded via migrations.

**Programmatic Landing Pages:**
- **Structure:** `/{vertical}/{city}` (e.g., `/catering/berlin`).
- **Data Source:** Driven by `seo_content_pages` which allows the Admin to override auto-generated content (H1s, intro text) for specific city + category combinations.
- **Implemented:** `Partial`. The database tables exist, but the dynamic TanStack router paths for explicit programmatic GEO pages (e.g., matching a slug to a specific city) are currently underdeveloped or mocked.

## 2. Technical SEO Structure

**Title & Meta Patterns**
- **Pattern:** Managed via TanStack Router's `head` callback in route definitions.
- **Example (Partner Profile):** `Title: [Partner Name] - [Category] in [City] | Speisely`
- **Implemented:** `Partial`. Many routes still use static fallbacks.

**Heading Structure**
- H1: Partner Name or Page Category.
- H2: Menu Categories, Services, About sections.
- **Implemented:** `Built`.

**Schema Markup (JSON-LD)**
- **Opportunities:**
  - `Restaurant` schema for restaurant profiles.
  - `FoodEstablishment` or `LocalBusiness` for caterers and planners.
  - `Product` schema for menu items.
  - `AggregateRating` for reviews.
- **Implemented:** `Missing`. No dynamic JSON-LD injection found in the SSR flow.

**Canonical URLs**
- **Logic:** Must point to the primary `speisely.de` path to avoid duplicate content penalties from custom domains/subdomains.
- **Example:** `pizza.speisely.de` canonicalizes to `https://speisely.de/restaurant/pizza`.
- **Implemented:** `Missing / Partial`.

## 3. SEO Opportunities by Role

**Restaurant SEO:**
- Target: "Order [Cuisine] in [City]"
- Profiles contain rich text descriptions and menu items.

**Caterer SEO:**
- Target: "[Event Type] Catering [City]" (e.g., Wedding Catering Berlin)
- Packages and Minimum Order Values provide good structured data.

**Event Manager SEO:**
- Target: "Event Planner [City]"
- Portfolio images (Image SEO alt tags) are critical here.

## 4. Crawlability & Indexing

**Sitemap (`sitemap.xml.ts`)**
- **Logic:** Dynamically generated API route that queries Supabase for all active slugs across restaurants, caterers, and planners.
- **Implemented:** `Built`.

**Robots.txt**
- Allows crawling of main directories, disallows `/_authenticated/*` and `/admin/*`.
- **Implemented:** `Assumed / Built`.

## Current Gaps & Content Needs

1. **Schema Markup:** Missing completely. This is the biggest technical gap for Google discoverability.
2. **Image SEO:** Partner uploaded images (banners, portfolio, products) often lack descriptive `alt` tags.
3. **Internal Linking:** The homepage links to main directories, but deep cross-linking (e.g., linking related cities together, or "Other Caterers in Berlin" at the bottom of a profile) is weak.
