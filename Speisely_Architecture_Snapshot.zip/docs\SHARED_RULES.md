# Speisely Shared Business Rules

This document outlines the core business logic, boundaries, and validation rules that apply globally across the Speisely platform.

## 1. Authentication & Identity Boundaries

**Unified Partner Identity**
- **Rule:** A single user can act as a Customer, Restaurant Owner, Caterer, and Event Manager simultaneously.
- **Implementation:** `role-middleware.ts` automatically injects a `partner` role array if the user holds any specific vendor role (`restaurant_owner`, `caterer`, `planner`).
- **Status:** `Built` & Active.

**Separation of Operational Workspaces**
- **Rule:** Despite unified identity, workspaces are strictly segregated. A user managing their Restaurant sees a different dashboard (`/_authenticated/restaurant`) than when managing Catering (`/_authenticated/caterer`).
- **Reasoning:** Keeps UI clean, prevents accidental mixing of distinct business models (Instant vs Quoted).
- **Status:** `Built` & Active.

## 2. Anti-Fraud & Date Validation Logic

**No Past-Date Abuse**
- **Rule:** Customers cannot book tables, submit catering inquiries, or request planners for dates in the past.
- **Frontend Validation:** Zod schemas and date pickers explicitly block past dates.
- **Backend Validation:** Server functions (`createServerFn`) enforce strict `Date() >= today` rules.
- **Status:** `Built` (via `createTableReservation` and Zod validators).

**Vendor Calendar Sync**
- **Rule:** Customers cannot book on days marked as unavailable by the vendor.
- **Data Source:** Validates against `availability` (recurring days) and `vendor_blackout_dates` (specific dates).
- **Status:** `Built`.

## 3. Promo Engine Rules

**Usage & Validation**
- **Rule:** Promo codes apply specifically to the total cart/booking value.
- **Types:** Percentage, Fixed Amount, Free Delivery, Free Item, BOGO.
- **Validation:** Must meet `min_order_value_cents`. Dates must be between `starts_at` and `ends_at`.
- **Status:** `Built` in Data types. UI evaluation is `Partial` (often mocked in storefronts).

## 4. Payment & Checkout Rules

**Stripe Connect**
- **Rule:** All partner payouts run through Stripe Connect.
- **Storage Strategy:** Stripe Account IDs must be stored securely. Migration from public `restaurants.stripe_user_id` to private `restaurant_stripe_accounts.stripe_user_id` is underway to prevent public exposure.
- **Checkout Flow:** Users do not pay directly on Speisely pages. They are redirected to Stripe Checkout Sessions (`startStorefrontCheckout` function).
- **Status:** `Built`.

## 5. Notification & Communication Rules

**Email Triggers (Resend)**
- **Rule:** System-critical emails (Confirmations, Quotes, Reset Password) use `sendEmail` helper.
- **Inbox Logic:** Messages between customers and partners are stored in `messages` and `brief_messages`.
- **Status:** `Partial`. Missing robust in-app push/toast alerts for real-time events (like Kitchen KDS).

## 6. Immutable Core Principles

- **Do Not Break Legacy Logic:** When refactoring database columns (e.g., Stripe IDs), fallback to old columns if the new table query fails, ensuring zero downtime.
- **No Re-opening Decisions:** Unified identity vs strict workspace separation is a finalized decision. Do not attempt to merge operational dashboards.
