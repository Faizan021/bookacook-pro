# Speisely Data Map

This document outlines all core tables in the Supabase database (`src/integrations/supabase/types.ts`), detailing their purpose, relationships, and current status (Active, Legacy, Duplicate, or Unclear).

## 1. Core System & Auth Tables

| Table Name | Purpose | Key Columns | Used By Role | Storefront Usage | Status |
|---|---|---|---|---|---|
| `profiles` | Stores standard user profile info linking to Supabase Auth. | `id` (PK, Auth UID), `first_name`, `email` | All | N/A (Internal auth logic) | **Active** |
| `user_roles` | Manages explicit role assignments (admin, customer, partner). | `user_id`, `role` | Admin, System | N/A | **Active** |
| `seo_content_pages` | Drives programmatic SEO pages (e.g. Catering in Berlin). | `slug`, `city`, `category`, `h1_heading` | Admin | `/catering/[city]` | **Active** (Partial UI) |
| `german_locations` | Base geographic data for GEO strategy. | `city`, `zipcode`, `lat`, `lng` | System | N/A | **Active** |

## 2. Restaurant Operational Tables

| Table Name | Purpose | Key Columns | Used By Role | Storefront Usage | Status |
|---|---|---|---|---|---|
| `restaurants` | Core profile for instant order / reservation partners. | `id`, `slug`, `custom_domain`, `is_published` | Restaurant | `/restaurant/[slug]` | **Active** |
| `restaurant_products` | Menu items offered by the restaurant. | `restaurant_id`, `name`, `price` | Restaurant | `/restaurant/[slug]` | **Active** |
| `product_categories` | Menu categorization. | `name`, `restaurant_id` | Restaurant | Menu Sections | **Active** |
| `restaurant_orders` | Tracks instant food orders. | `restaurant_id`, `status`, `total` | Restaurant, Customer | Checkout / KDS | **Active** |
| `order_items` | Specific products inside a `restaurant_order`. | `order_id`, `product_id`, `qty` | Restaurant, Customer | Checkout / KDS | **Active** |
| `table_reservations` | Stores booking intents for physical tables. | `restaurant_id`, `reservation_date`, `reservation_time` | Restaurant, Customer | `/restaurant/[slug]` | **Active** |

## 3. Catering Operational Tables

| Table Name | Purpose | Key Columns | Used By Role | Storefront Usage | Status |
|---|---|---|---|---|---|
| `caterers` | Core profile for event caterers. | `id`, `slug`, `minimum_order_value` | Caterer | `/caterer/[slug]` | **Active** |
| `caterer_menu_items` | Packages and items offered by caterers. | `caterer_id`, `price` | Caterer | `/caterer/[slug]` | **Active** |
| `catering_bookings` | Inquiries and booked events for caterers. | `caterer_id`, `status` (pending, quoted, paid) | Caterer, Customer | `/caterer/[slug]` | **Active** |
| `catering_briefs` | Detailed event requirements submitted by customers. | `booking_id`, `guest_count`, `budget` | Caterer, Customer | Inquiry Form | **Active** |
| `catering_matches` | Stores system/admin logic for matching briefs to caterers. | `brief_id`, `caterer_id` | Admin, System | N/A | **Unclear** (Possible legacy) |

## 4. Event Planner Operational Tables

| Table Name | Purpose | Key Columns | Used By Role | Storefront Usage | Status |
|---|---|---|---|---|---|
| `planners` | Core profile for event decorators and planners. | `id`, `slug`, `portfolio_urls` | Event Manager | `/planner/[slug]` | **Active** |
| `planner_services` | Specific services (e.g. Wedding Decor). | `planner_id`, `title`, `base_price` | Event Manager | `/planner/[slug]` | **Active** |
| `event_bookings` | Leads and confirmed bookings for planners. | `planner_id`, `status` | Event Manager, Customer | `/planner/[slug]` | **Active** |
| `event_requests` | Broader system for customer requests matching to planners. | `customer_id`, `event_type` | System | N/A | **Unclear / Duplicate** (Overlaps with `event_bookings`) |

## 5. Shared Partner Capabilities

| Table Name | Purpose | Key Columns | Used By Role | Storefront Usage | Status |
|---|---|---|---|---|---|
| `availability` | Recurring availability for partners (e.g. Open Mon-Fri). | `partner_id`, `day_of_week` | Caterer, Planner | Date Pickers | **Active** |
| `vendor_blackout_dates` | Specific dates blocked off by partners. | `vendor_id`, `date` | Caterer, Planner | Date Pickers | **Active** |
| `promo_codes` | Discount logic engine. | `code`, `discount_type`, `discount_value` | Admin, Partners | Checkout | **Active** |
| `reviews` | Customer feedback on partners. | `partner_id`, `rating`, `comment` | Customer | Profile Pages | **Active** (UI Partial) |
| `saved_caterers` | Customers saving favorite partners. | `customer_id`, `caterer_id` | Customer | N/A | **Active** |
| `storefront_page_views` | Analytics tracking hits on public profiles. | `vendor_id`, `url` | System | N/A | **Active** |

## 6. Financial & Communication Tables

| Table Name | Purpose | Key Columns | Used By Role | Storefront Usage | Status |
|---|---|---|---|---|---|
| `payments` | Tracks Stripe payment intents and status. | `booking_id`, `stripe_id` | System | Checkout | **Active** |
| `subscriptions` | Tracks SaaS platform fees paid by partners (if applicable). | `partner_id`, `stripe_id` | Admin, System | N/A | **Unclear** (Likely future B2B feature) |
| `messages` | Direct chat between customers and partners. | `sender_id`, `receiver_id`, `content` | Customer, Partners | N/A | **Active** |
| `brief_messages` | Chat specifically tied to a `catering_brief`. | `brief_id`, `content` | Customer, Caterer | N/A | **Active / Duplicate** (Overlaps with `messages`) |

## 7. Known Legacy / Deprecated / Unclear Tables

- `orders` vs `restaurant_orders`: `orders` is a generic legacy table. Current system uses `restaurant_orders` specifically for instant food. `orders` should be considered **Legacy**.
- `quotes` and `quote_items`: Likely **Legacy** or duplicate logic superseded by `catering_bookings` status updates.
- `restaurant_stripe_accounts` (Private schema): Intended to replace public `stripe_user_id` columns for security. **Migration In Progress**.
