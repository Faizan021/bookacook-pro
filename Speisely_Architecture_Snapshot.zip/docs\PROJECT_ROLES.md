# Speisely Project Roles & Permissions

This document maps the real, current state of the codebase for the 5 primary user roles in the Speisely platform.

## 1. Admin

**Role Purpose:**
Superuser role for managing platform-wide settings, user roles, moderation, and SEO content.

**Account Type / Login / Onboarding Flow:**
- Logs in via standard Supabase auth.
- Must have the `admin` role assigned manually in the `user_roles` table. (This role is NOT self-healable from metadata).

**Dashboard / Workspace Structure:**
- Centralized control panel with tabs for Users, Restaurants, Caterers, Planners, and SEO Content.

**Pages & Routes:**
- `/admin` (Primary admin dashboard)

**Actions:**
- Moderate user roles (assign/revoke roles).
- Edit and manage SEO content pages and categories.
- View platform-wide statistics (assumed from standard admin panels, partially implemented).
- Override partner statuses (approve/reject partners).

**Data Stored:**
- Platform-wide configurations and SEO content.

**Profile Fields & Settings:**
- Standard user profile (name, email) in `profiles`.

**Booking / Promo / Date Logic:**
- N/A (Admins do not book or offer promos directly).

**Notifications:**
- [MISSING] System-wide alerts for new partner registrations.

**Permissions & Restrictions:**
- Full read/write access to all public and administrative tables via RLS policies or service role keys in server functions.

**Related Database Tables:**
- `user_roles`, `seo_content_pages`, `german_locations`

**Related Server Functions:**
- General admin mutation capabilities (usually via service role key bypass in server functions).

**Status & Gaps:**
- **Status:** `Partial`
- **Gaps/Risks:** The admin panel currently focuses heavily on SEO and basic user management. Moderation workflows (e.g., payout approvals, dispute resolution) are missing or assumed to be handled directly via Stripe dashboard.

---

## 2. Customer

**Role Purpose:**
End-user who browses the storefront, orders food, books tables, and requests event services.

**Account Type / Login / Onboarding Flow:**
- Standard email/password or magic link auth.
- Defaults to `customer` role if no other role is assigned.

**Dashboard / Workspace Structure:**
- Unified customer dashboard with tabs: Overview, Profile, Orders, Reservations, Catering Bookings, Event Bookings, Saved Partners.

**Pages & Routes:**
- `/_authenticated/customer` (Customer Dashboard)
- All public storefront routes (`/`, `/restaurant/$slug`, `/caterer/$slug`, `/planner/$slug`, etc.)

**Actions:**
- Place instant food orders.
- Book restaurant tables.
- Submit catering inquiries and accept quotes.
- Request event planner services.
- Save favorite caterers/restaurants.

**Data Stored:**
- Personal details, order history, active bookings, saved preferences.

**Profile Fields & Settings:**
- Name, phone, email, avatar, marketing opt-in, terms acceptance.

**Booking / Ordering / Inquiry Flows:**
- **Restaurant:** Instant order checkout (Stripe), Table reservation form (auto-confirmed).
- **Caterer:** Two-step quote request -> accept quote -> pay deposit -> final payment.
- **Planner:** Lead capture form -> messaging -> booking.

**Promo / Offer / Coupon Logic:**
- Can apply promo codes during checkout for instant orders and catering. Validates against `promo_codes` table.

**Date Validation Rules:**
- Cannot book past dates.
- Must respect caterer/planner `availability` and `vendor_blackout_dates`.

**Notifications:**
- Email confirmations for bookings, orders, and quotes via Resend (`sendEmail` server functions).

**Permissions & Restrictions:**
- Can only view and edit their own orders and profile (enforced via RLS `auth.uid() = customer_id`).

**Related Database Tables:**
- `profiles`, `orders`, `table_reservations`, `catering_bookings`, `event_bookings`, `saved_caterers`, `payments`.

**Related Server Functions:**
- `createTableReservation`, `startStorefrontCheckout`, `submitCateringRequest`.

**Status & Gaps:**
- **Status:** `Built` (mostly functional).
- **Gaps/Risks:** Lack of advanced order tracking UI (live maps). Unified inbox for customer-to-vendor chat is partial.

---

## 3. Caterer

**Role Purpose:**
Provides food catering services for events, either daily (B2B) or one-off events.

**Account Type / Login / Onboarding Flow:**
- Registers as a partner. Self-healing assigns `caterer` metadata role, which middleware upgrades to `caterer` and unified `partner` role.
- Connects Stripe for payouts.

**Dashboard / Workspace Structure:**
- Dedicated workspace with tabs: Inquiries, Bookings, Menu, Calendar, Settings.

**Pages & Routes:**
- `/_authenticated/caterer` (Caterer Dashboard)

**Actions:**
- Manage catering menu items and packages.
- Respond to customer inquiries (create quotes, send messages).
- Manage calendar availability and blackout dates.
- Configure Stripe payouts.

**Data Stored:**
- Business details, menu items, dietary tags, service radius, minimum order values.

**Profile Fields & Settings:**
- Business name, slug, description, banner/logo, address, phone, tax ID, minimum guest count, lead time days.

**Booking / Ordering / Inquiry Flows:**
- Receives `catering_bookings` in "pending" status.
- Reviews details, updates status to "quote_sent" with pricing.
- Customer accepts -> status "deposit_paid" -> event happens -> "completed".

**Promo / Offer Logic:**
- Can configure discount codes specific to their catering services.

**Date Validation Rules:**
- Drives the `availability` and `vendor_blackout_dates` logic. Customers cannot book on blacked-out dates.

**Notifications:**
- Receives emails for new inquiries and deposit payments.

**Permissions & Restrictions:**
- RLS ensures they can only view and mutate data where `caterer_id = auth.uid()`.

**Related Database Tables:**
- `caterers`, `caterer_menu_items`, `catering_bookings`, `availability`, `vendor_blackout_dates`, `promo_codes`, `messages`.

**Related Server Functions:**
- `createCatererQuote`, `updateCateringStatus`, `getAvailableDates`.

**Status & Gaps:**
- **Status:** `Built`
- **Gaps/Risks:** Complex calendar logic (recurring unavailability vs one-off blackouts) needs robust UI testing.

---

## 4. Restaurant

**Role Purpose:**
Local dining establishments offering table reservations and instant food ordering (takeaway/delivery).

**Account Type / Login / Onboarding Flow:**
- Registers as a partner. Assigned `restaurant_owner` and unified `partner` role.
- Must configure Stripe and menu before publishing.

**Dashboard / Workspace Structure:**
- Split into management and operational views:
  - Dashboard: Settings, Menu Builder, Promo Codes, Reservations.
  - Kitchen Display System (KDS): Live order ticket management.

**Pages & Routes:**
- `/_authenticated/restaurant` (Management Dashboard)
- `/_authenticated/restaurant.kitchen` (Live Kitchen Display)

**Actions:**
- Edit restaurant profile, custom domain, and slug.
- Build menu with categories, items, variants, and dietary tags.
- Manage incoming table reservations.
- Fulfill instant food orders via KDS.

**Data Stored:**
- Storefront config, opening hours, capacity, menu products, Stripe connect state.

**Profile Fields & Settings:**
- Name, slug, custom domain, banner/logo, address, opening hours, seat capacity, delivery radius, `accepts_cash`, `accepts_paypal`.

**Booking / Ordering / Inquiry Flows:**
- **Reservations:** Auto-confirmed if under capacity limit.
- **Orders:** Paid upfront via Stripe -> pops up on KDS -> Kitchen accepts -> Kitchen completes.

**Promo / Offer Logic:**
- Extensive promo capabilities: percentage, fixed, free delivery, BOGO. Stored in `promo_codes`.

**Date Validation Rules:**
- Table reservations validate against `seat_capacity` per time slot. Time slots forced to HH:MM:00.

**Notifications:**
- [PARTIAL] Need real-time sound/push alerts for new orders on the KDS.

**Permissions & Restrictions:**
- RLS restricts access to `restaurant_id = auth.uid()`.

**Related Database Tables:**
- `restaurants`, `restaurant_products`, `product_categories`, `restaurant_orders`, `order_items`, `table_reservations`, `restaurant_stripe_accounts`.

**Related Server Functions:**
- `createTableReservation`, `acceptRestaurantOrder`, `completeRestaurantOrder`.

**Status & Gaps:**
- **Status:** `Built`
- **Gaps/Risks:** Custom domains logic relies on Vercel API and DNS, which is complex. Instant order fulfillment needs robust real-time updates (Supabase Realtime is used but needs fail-safes).

---

## 5. Event Manager (Planner)

**Role Purpose:**
Professionals who plan and coordinate events (weddings, corporate parties). Acts as a service provider and sometimes a broker.

**Account Type / Login / Onboarding Flow:**
- Registers as partner. Assigned `planner` and unified `partner` role.

**Dashboard / Workspace Structure:**
- Kanban-style board for Lead tracking, Services manager, Calendar, Settings.

**Pages & Routes:**
- `/_authenticated/dashboard/planner`

**Actions:**
- Define event planning services and packages.
- Track leads via a drag-and-drop Kanban board (Inquiry -> Negotiating -> Booked -> Completed).
- Chat with clients.

**Data Stored:**
- Portfolio images, service descriptions, base pricing, lead tracking statuses.

**Profile Fields & Settings:**
- Business name, slug, locations covered, specialties (weddings, corporate, etc.), about text, portfolio gallery.

**Booking / Ordering / Inquiry Flows:**
- Highly conversational. Customer submits inquiry -> Planner receives lead -> Planner chats with customer -> Manual contract/booking outside system or via custom Stripe invoice (assumed/partial).

**Promo / Offer Logic:**
- [MISSING / ASSUMED] Planners typically don't use coupon codes; they use custom quotes.

**Date Validation Rules:**
- Manual calendar management.

**Notifications:**
- Email alerts on new leads.

**Permissions & Restrictions:**
- RLS restricts to `planner_id = auth.uid()`.

**Related Database Tables:**
- `planners`, `planner_services`, `event_bookings` (leads), `event_requests`.

**Related Server Functions:**
- Lead status updates, portfolio uploads.

**Status & Gaps:**
- **Status:** `Partial`
- **Gaps/Risks:** The workflow relies heavily on chat/negotiation. A formal quoting and payment flow within the platform for Planners is currently weak compared to Caterers.

---

## Permissions Matrix & Key Routes

| Role | Auth Role String | Dashboard Route | Key Owned Tables | Self-Healable? |
|---|---|---|---|---|
| Admin | `admin` | `/admin` | `seo_content_pages` | No |
| Customer | `customer` | `/_authenticated/customer` | `profiles`, `orders`, `table_reservations` | Yes |
| Caterer | `caterer`, `partner` | `/_authenticated/caterer` | `caterers`, `caterer_menu_items`, `catering_bookings` | Yes |
| Restaurant | `restaurant_owner`, `partner` | `/_authenticated/restaurant` | `restaurants`, `restaurant_products`, `restaurant_orders` | Yes |
| Event Manager | `planner`, `partner` | `/_authenticated/dashboard/planner` | `planners`, `planner_services`, `event_bookings` | Yes |

*Note: The unified `partner` role is injected by middleware for any user possessing `caterer`, `restaurant_owner`, or `planner`. This enables shared partner features like unified billing or cross-selling in the future.*
