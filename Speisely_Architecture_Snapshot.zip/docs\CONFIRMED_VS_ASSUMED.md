# Speisely Confirmed vs. Assumed Logic

This document clearly separates the **verified facts** (traced directly in the codebase) from **inferred or assumed logic** (features that seem intended but lack complete implementation).

## 1. Authentication & Roles

### ✅ Confirmed (Fact)
- The system supports `admin`, `customer`, `restaurant_owner`, `caterer`, and `planner` roles.
- The `role-middleware.ts` successfully reads auth claims, checks the `user_roles` table, and applies a "self-healing" mechanism for missing roles using metadata.
- A unified `partner` role is automatically injected for any vendor.
- RLS (Row Level Security) is fully active and protects mutations across almost all tables based on user ID matching.

### ❓ Assumed / Missing
- **Assumed:** Admin moderation workflows (e.g., manually approving a restaurant before it goes live). 
- **Reality:** RLS currently allows partners to insert/update their own records freely. The `is_published` toggle exists, but enforcement of "admin approval required" is weak or missing.

## 2. Storefront Routing

### ✅ Confirmed (Fact)
- `src/server.ts` intercepts requests and performs Edge/Server-level routing.
- It correctly parses `host` headers to detect wildcard subdomains (e.g., `pizza.speisely.de`) and custom domains (e.g., `pizzeria.com`).
- The 404 logic for missing restaurant slugs throws a proper `notFound()` error, triggering the TanStack fallback UI.

### ❓ Assumed / Missing
- **Assumed:** SSL provisioning for custom domains.
- **Reality:** The code handles the routing, but the actual SSL certificate generation and DNS verification rely entirely on Vercel's Domains API, which requires manual or separate programmatic setup not fully present in the app code.

## 3. SEO and GEO Strategy

### ✅ Confirmed (Fact)
- The database contains `german_locations` and `seo_content_pages`.
- The sitemap (`sitemap.xml.ts`) dynamically pulls live slugs from the database to ensure search engines can index partner pages.

### ❓ Assumed / Missing
- **Assumed:** The frontend dynamically renders localized pages (e.g., `/catering/berlin`) utilizing the `seo_content_pages` data.
- **Reality:** While the data structures exist, dynamic injection of Schema Markup (JSON-LD) is completely missing. Deep integration of the GEO strategy into the TanStack router paths is heavily mocked or incomplete.

## 4. Bookings & Checkout

### ✅ Confirmed (Fact)
- `startStorefrontCheckout` correctly creates Stripe Checkout Sessions.
- `createTableReservation` strictly enforces capacity logic (`seat_capacity`) and blocks past dates.
- Caterer quote flow accurately shifts states from `pending` -> `quote_sent` -> `deposit_paid`.

### ❓ Assumed / Missing
- **Assumed:** Event Planners have a functional payment pipeline.
- **Reality:** Event Planners currently capture leads via `event_bookings`, but the payment mechanics (invoicing, deposits) specific to Planners are missing or rely on off-platform billing.
- **Assumed:** Real-time Kitchen Display System (KDS) alerts.
- **Reality:** The UI polls or uses basic subscriptions, but lacks robust audio/push notifications for kitchen staff when a new order arrives.

## 5. Reviews System

### ✅ Confirmed (Fact)
- The `reviews` table exists in Supabase.

### ❓ Assumed / Missing
- **Assumed:** Customers can leave reviews after an order, and the storefront displays aggregate ratings.
- **Reality:** The UI components for displaying reviews on the storefront (e.g., `/restaurant/$slug.tsx`) use mocked data arrays (`const reviews: any[] = []`). The actual read/write logic for reviews is missing from the public components.
